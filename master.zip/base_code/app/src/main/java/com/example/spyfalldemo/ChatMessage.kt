package com.example.spyfalldemo

//sets the formatting gor chat messages
data class ChatMessage(val sender : String = "", val content : String = "")